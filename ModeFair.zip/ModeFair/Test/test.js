const { Builder, By, Key, until } = require('selenium-webdriver');
const assert = require('assert');

//TC001
async function convertUSDToEUR() {
    let driver = await new Builder().forBrowser('chrome').build();
    try {
        await driver.get('https://www.xe.com/');
        await driver.findElement(By.id('midmarketFromCurrency')).sendKeys('USD');
        await driver.findElement(By.id('midmarketToCurrency')).sendKeys('EUR');
        await driver.findElement(By.id('amount')).sendKeys('100');
        await driver.findElement(By.id('convert')).click();
        let result = await driver.wait(until.elementLocated(By.id('result')), 10000).getText();
        console.log(`Conversion Result: ${result}`);
        assert(result.includes('EUR'));
    } finally {
        await driver.quit();
    }
}

//TC002
async function convertDecimal() {
    let driver = await new Builder().forBrowser('chrome').build();
    try {
        await driver.get('https://www.xe.com/');
        await driver.findElement(By.id('midmarketFromCurrency')).sendKeys('USD');
        await driver.findElement(By.id('midmarketToCurrency')).sendKeys('EUR');
        await driver.findElement(By.id('amount')).sendKeys('123.45678');
        await driver.findElement(By.id('convert')).click();
        let result = await driver.wait(until.elementLocated(By.id('result')), 10000).getText();
        console.log(`Conversion Result: ${result}`);
        assert(result.includes('EUR'));
    } finally {
        await driver.quit();
    }
}

//TC003
async function invalidAmountInput() {
    let driver = await new Builder().forBrowser('chrome').build();
    try {
        await driver.get('https://www.xe.com/');
        await driver.findElement(By.id('midmarketFromCurrency')).sendKeys('USD');
        await driver.findElement(By.id('midmarketToCurrency')).sendKeys('EUR');
        await driver.findElement(By.id('amount')).sendKeys('-100');
        await driver.findElement(By.id('convert')).click();
        let result = await driver.wait(until.elementLocated(By.id('result')), 10000).getText();
        console.log(`Conversion Result: ${result}`);
        assert(result.includes('EUR'));
    } finally {
        await driver.quit();
    }
}

//TC004
async function convertZeroAmount() {
    let driver = await new Builder().forBrowser('chrome').build();
    try {
        await driver.get('https://www.xe.com/');
        await driver.findElement(By.id('midmarketFromCurrency')).sendKeys('USD');
        await driver.findElement(By.id('midmarketToCurrency')).sendKeys('EUR');
        await driver.findElement(By.id('amount')).sendKeys('0');
        await driver.findElement(By.id('convert')).click();
        let result = await driver.wait(until.elementLocated(By.id('result')), 10000).getText();
        console.log(`Conversion Result: ${result}`);
        assert(result.includes('EUR'));
    } finally {
        await driver.quit();
    }
}

//TC005
async function conversionWithDifferentCurrencyPairs() {
    let driver = await new Builder().forBrowser('chrome').build();
    try {
        await driver.get('https://www.xe.com/');
        await driver.findElement(By.id('midmarketFromCurrency')).sendKeys('GBP');
        await driver.findElement(By.id('midmarketToCurrency')).sendKeys('JPY');
        await driver.findElement(By.id('amount')).sendKeys('1000');
        await driver.findElement(By.id('convert')).click();
        let result = await driver.wait(until.elementLocated(By.id('result')), 10000).getText();
        console.log(`Conversion Result: ${result}`);
        assert(result.includes('JPY'));
    } finally {
        await driver.quit();
    }
}

convertUSDToEUR();
convertDecimal();
invalidAmountInput();
convertZeroAmount();
conversionWithDifferentCurrencyPairs();